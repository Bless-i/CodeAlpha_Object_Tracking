# CodeAlpha Object Tracking Project

## 📘 Description
This project detects and tracks moving objects in videos using 'YOLOv8' for detection and 'SORT (Simple Online and Realtime Tracking)'' for tracking.

It was built as part of the 'CodeAlpha Internship' tasks.

## 🧩 Requirements
Install dependencies:

```
```
